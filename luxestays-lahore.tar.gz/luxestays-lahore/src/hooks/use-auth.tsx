import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type AuthUser = {
  name: string;
  email: string;
};

type StoredAccount = AuthUser & { password: string };

type AuthContextValue = {
  user: AuthUser | null;
  login: (email: string, password: string) => { ok: true } | { ok: false; error: string };
  signup: (
    name: string,
    email: string,
    password: string,
  ) => { ok: true } | { ok: false; error: string };
  logout: () => void;
};

const ACCOUNTS_KEY = "luxestays.accounts";
const SESSION_KEY = "luxestays.session";

const AuthContext = createContext<AuthContextValue | null>(null);

function readAccounts(): StoredAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAccounts(accounts: StoredAccount[]) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {
      setUser(null);
    }
  }, []);

  const persistSession = (next: AuthUser | null) => {
    setUser(next);
    if (next) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(next));
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  };

  const signup: AuthContextValue["signup"] = (name, email, password) => {
    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();
    if (cleanName.length < 2) return { ok: false, error: "Please enter your full name." };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail))
      return { ok: false, error: "Please enter a valid email address." };
    if (password.length < 6)
      return { ok: false, error: "Password must be at least 6 characters." };

    const accounts = readAccounts();
    if (accounts.some((a) => a.email === cleanEmail))
      return { ok: false, error: "An account with this email already exists." };

    const account: StoredAccount = { name: cleanName, email: cleanEmail, password };
    writeAccounts([...accounts, account]);
    persistSession({ name: account.name, email: account.email });
    return { ok: true };
  };

  const login: AuthContextValue["login"] = (email, password) => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password)
      return { ok: false, error: "Please enter your email and password." };
    const accounts = readAccounts();
    const match = accounts.find((a) => a.email === cleanEmail);
    if (!match) return { ok: false, error: "No account found with that email." };
    if (match.password !== password) return { ok: false, error: "Incorrect password." };
    persistSession({ name: match.name, email: match.email });
    return { ok: true };
  };

  const logout = () => persistSession(null);

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>{children}</AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
