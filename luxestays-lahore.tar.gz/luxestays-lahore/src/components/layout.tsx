import { Link } from "wouter";
import { Heart, Menu, MapPin, Phone, Mail, Instagram, Facebook, Twitter, LogOut, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFavorites } from "@/hooks/use-favorites";
import { useAuth } from "@/hooks/use-auth";
import { AuthDialog } from "@/components/auth-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Header() {
  const { favorites } = useFavorites();
  const { user, logout } = useAuth();
  const initials = user
    ? user.name
        .split(" ")
        .map((p) => p[0])
        .join("")
        .slice(0, 2)
        .toUpperCase()
    : "";

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-serif font-bold text-xl group-hover:bg-secondary transition-colors">
            L
          </div>
          <span className="font-serif font-bold text-2xl tracking-tight text-foreground">LuxeStays</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-sm font-medium hover:text-secondary transition-colors">Home</Link>
          <Link href="/hotels" className="text-sm font-medium hover:text-secondary transition-colors">Hotels</Link>
          <Link href="/about" className="text-sm font-medium hover:text-secondary transition-colors">About</Link>
          <Link href="/contact" className="text-sm font-medium hover:text-secondary transition-colors">Contact</Link>
        </nav>

        <div className="flex items-center gap-4">
          <Link href="/favorites" className="relative p-2 hover:text-secondary transition-colors">
            <Heart className="w-5 h-5" />
            {favorites.length > 0 && (
              <span className="absolute top-0 right-0 w-4 h-4 bg-secondary text-secondary-foreground text-[10px] font-bold flex items-center justify-center rounded-full">
                {favorites.length}
              </span>
            )}
          </Link>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="hidden md:flex items-center gap-2 rounded-full border border-primary/40 pl-1 pr-4 py-1 hover:border-secondary transition-colors"
                  data-testid="button-user-menu"
                >
                  <span className="w-8 h-8 rounded-full bg-secondary text-secondary-foreground font-semibold text-sm flex items-center justify-center">
                    {initials || <User className="w-4 h-4" />}
                  </span>
                  <span className="text-sm font-medium max-w-[120px] truncate">{user.name}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col">
                    <span className="font-semibold">{user.name}</span>
                    <span className="text-xs text-muted-foreground font-normal truncate">{user.email}</span>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/favorites" className="cursor-pointer">
                    <Heart className="w-4 h-4 mr-2" />
                    My Favorites
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => logout()}
                  className="cursor-pointer text-destructive focus:text-destructive"
                  data-testid="button-logout"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <AuthDialog
              trigger={
                <Button
                  variant="outline"
                  className="hidden md:flex border-primary text-primary hover:bg-primary hover:text-primary-foreground font-medium rounded-full px-6"
                  data-testid="button-open-login"
                >
                  Login
                </Button>
              }
            />
          )}

          <div className="md:hidden">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="w-9 h-9 rounded-full bg-secondary text-secondary-foreground font-semibold text-sm flex items-center justify-center"
                    data-testid="button-user-menu-mobile"
                  >
                    {initials || <User className="w-4 h-4" />}
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col">
                      <span className="font-semibold">{user.name}</span>
                      <span className="text-xs text-muted-foreground font-normal truncate">{user.email}</span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => logout()} className="cursor-pointer text-destructive focus:text-destructive">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <AuthDialog
                trigger={
                  <Button variant="ghost" size="icon" aria-label="Login">
                    <Menu className="w-5 h-5" />
                  </Button>
                }
              />
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground pt-20 pb-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-primary font-serif font-bold text-xl">
                L
              </div>
              <span className="font-serif font-bold text-2xl tracking-tight text-white">LuxeStays</span>
            </Link>
            <p className="text-primary-foreground/70 text-sm leading-relaxed mb-6">
              Curating the finest luxury hotel experiences in Lahore. Elevate your stay with our handpicked selection of premium properties.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-colors"><Instagram className="w-4 h-4" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-colors"><Twitter className="w-4 h-4" /></a>
            </div>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold mb-6 text-secondary">Quick Links</h4>
            <ul className="space-y-4">
              <li><Link href="/" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Home</Link></li>
              <li><Link href="/hotels" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Browse Hotels</Link></li>
              <li><Link href="/about" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Our Story</Link></li>
              <li><Link href="/contact" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold mb-6 text-secondary">Popular Areas</h4>
            <ul className="space-y-4">
              <li><Link href="/hotels?area=Gulberg" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Gulberg</Link></li>
              <li><Link href="/hotels?area=DHA" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">DHA Lahore</Link></li>
              <li><Link href="/hotels?area=Mall Road" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Mall Road</Link></li>
              <li><Link href="/hotels?area=Bahria Town" className="text-primary-foreground/70 hover:text-white transition-colors text-sm">Bahria Town</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold mb-6 text-secondary">Get in Touch</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-primary-foreground/70 text-sm">
                <MapPin className="w-5 h-5 text-secondary shrink-0" />
                <span>Lahore, Pakistan</span>
              </li>
              <li className="flex flex-col gap-1">
                <span className="text-white font-medium">Hamza Nazeer</span>
                <div className="flex items-center gap-3 text-primary-foreground/70 text-sm mt-1">
                  <Phone className="w-5 h-5 text-secondary shrink-0" />
                  <a href="tel:03186732515" className="hover:text-white transition-colors">0318 6732515</a>
                </div>
                <div className="flex items-center gap-3 text-primary-foreground/70 text-sm mt-1">
                  <span className="w-5 h-5 shrink-0 flex items-center justify-center text-secondary font-bold">W</span>
                  <a href="https://wa.me/923186732515" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">WhatsApp</a>
                </div>
              </li>
              <li className="flex items-center gap-3 text-primary-foreground/70 text-sm pt-2">
                <Mail className="w-5 h-5 text-secondary shrink-0" />
                <a href="mailto:hamzanazeer@email.com" className="hover:text-white transition-colors">hamzanazeer@email.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-primary-foreground/50 text-sm">
            &copy; 2026 LuxeStays Lahore. Crafted by Hamza Nazeer.
          </p>
          <div className="flex gap-4 text-sm text-primary-foreground/50">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground selection:bg-secondary selection:text-primary">
      <Header />
      <main className="flex-1 flex flex-col">
        {children}
      </main>
      <Footer />
    </div>
  );
}