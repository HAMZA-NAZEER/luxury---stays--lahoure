import { Link } from "wouter";
import { Star, MapPin, Heart, Wifi, Waves, Wind, Utensils, Car, Dumbbell, Coffee, Martini } from "lucide-react";
import { Hotel, Amenity } from "@/data/hotels";
import { useFavorites } from "@/hooks/use-favorites";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const amenityIcons: Record<Amenity, React.ReactNode> = {
  wifi: <Wifi className="w-4 h-4" />,
  pool: <Waves className="w-4 h-4" />,
  spa: <Wind className="w-4 h-4" />,
  restaurant: <Utensils className="w-4 h-4" />,
  parking: <Car className="w-4 h-4" />,
  gym: <Dumbbell className="w-4 h-4" />,
  "room-service": <Coffee className="w-4 h-4" />,
  bar: <Martini className="w-4 h-4" />
};

export function HotelCard({ hotel }: { hotel: Hotel }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const isFav = isFavorite(hotel.id);

  return (
    <div className="group bg-card rounded-2xl overflow-hidden border border-border/50 hover:border-secondary/50 transition-all duration-500 hover:shadow-2xl hover:shadow-secondary/5 flex flex-col h-full hover:-translate-y-1">
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        <img 
          src={hotel.images[0]} 
          alt={hotel.name} 
          className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute top-4 right-4">
          <button 
            onClick={(e) => { e.preventDefault(); toggleFavorite(hotel.id); }}
            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-all ${isFav ? 'bg-destructive text-destructive-foreground' : 'bg-black/20 text-white hover:bg-black/40'}`}
          >
            <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
          </button>
        </div>
        <div className="absolute bottom-4 left-4">
          <Badge className="bg-background/90 text-foreground backdrop-blur-md hover:bg-background border-none px-3 py-1 font-semibold rounded-full shadow-lg">
            PKR {hotel.pricePerNight.toLocaleString()} / night
          </Badge>
        </div>
      </div>

      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-serif text-xl font-bold text-foreground line-clamp-1 group-hover:text-secondary transition-colors">
            {hotel.name}
          </h3>
          <div className="flex items-center gap-1 bg-secondary/10 px-2 py-1 rounded-md">
            <Star className="w-4 h-4 fill-secondary text-secondary" />
            <span className="text-sm font-bold">{hotel.guestRating}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-muted-foreground text-sm mb-4">
          <MapPin className="w-4 h-4" />
          <span>{hotel.area}, Lahore</span>
        </div>

        <div className="flex items-center gap-1 mb-6">
          {Array.from({ length: hotel.starRating }).map((_, i) => (
            <Star key={i} className="w-3.5 h-3.5 fill-secondary text-secondary" />
          ))}
        </div>

        <div className="flex flex-wrap gap-2 mb-6 mt-auto">
          {hotel.amenities.slice(0, 4).map(amenity => (
            <div key={amenity} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground" title={amenity}>
              {amenityIcons[amenity]}
            </div>
          ))}
          {hotel.amenities.length > 4 && (
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-medium text-muted-foreground">
              +{hotel.amenities.length - 4}
            </div>
          )}
        </div>

        <Link href={`/hotels/${hotel.id}`} className="w-full">
          <Button className="w-full rounded-full font-medium h-12 text-md transition-all group-hover:bg-secondary group-hover:text-primary">
            View Details
          </Button>
        </Link>
      </div>
    </div>
  );
}