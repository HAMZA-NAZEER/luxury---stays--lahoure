export type Amenity = "wifi" | "pool" | "spa" | "restaurant" | "parking" | "gym" | "room-service" | "bar";

export interface Review {
  id: string;
  author: string;
  rating: number;
  text: string;
  date: string;
}

export interface RoomType {
  name: string;
  price: number;
}

export interface Hotel {
  id: string;
  name: string;
  area: string;
  starRating: number;
  pricePerNight: number;
  description: string;
  amenities: Amenity[];
  roomTypes: RoomType[];
  images: string[];
  guestRating: number;
  reviewCount: number;
  reviews: Review[];
}

const defaultImages = [
  "/images/hotel-exterior-1.png",
  "/images/hotel-room-1.png",
  "/images/hotel-lobby-1.png",
  "/images/hotel-pool-1.png",
  "/images/hotel-restaurant-1.png",
];

const sampleReviews = [
  {
    id: "r1",
    author: "Ayesha K.",
    rating: 5,
    text: "An absolutely phenomenal experience. The luxury and attention to detail are unmatched in Lahore.",
    date: "2025-10-12"
  },
  {
    id: "r2",
    author: "Zain M.",
    rating: 4.5,
    text: "Beautiful property and excellent service. The dining options were fantastic.",
    date: "2025-09-28"
  },
  {
    id: "r3",
    author: "Sarah L.",
    rating: 5,
    text: "From the moment we stepped into the lobby, we were treated like royalty. Highly recommended for a staycation.",
    date: "2025-11-05"
  }
];

export const hotels: Hotel[] = [
  {
    id: "pearl-continental-lahore",
    name: "Pearl Continental Lahore",
    area: "Mall Road",
    starRating: 5,
    pricePerNight: 28000,
    description: "Experience the epitome of luxury at Pearl Continental Lahore. Located in the heart of the city, this five-star hotel offers unparalleled elegance, world-class dining, and impeccable service. Whether you're visiting for business or leisure, our opulent rooms and state-of-the-art facilities ensure a memorable stay.\n\nIndulge in our award-winning restaurants, relax by the expansive outdoor pool, or rejuvenate at our signature spa. The grand architecture and warm hospitality make it a true landmark of luxury in Pakistan.",
    amenities: ["wifi", "pool", "spa", "restaurant", "parking", "gym", "room-service", "bar"],
    roomTypes: [
      { name: "Deluxe Room", price: 28000 },
      { name: "Executive Suite", price: 45000 },
      { name: "Presidential Suite", price: 85000 }
    ],
    images: defaultImages,
    guestRating: 4.8,
    reviewCount: 1245,
    reviews: sampleReviews
  },
  {
    id: "avari-lahore",
    name: "Avari Lahore",
    area: "Mall Road",
    starRating: 5,
    pricePerNight: 26500,
    description: "Avari Lahore stands as a beacon of traditional hospitality blended with modern luxury. Surrounded by lush green gardens, it offers a serene oasis away from the bustling city streets. The classic interior design pays homage to Lahore's rich cultural heritage while providing contemporary comforts.\n\nGuests can savor exquisite culinary delights across multiple dining venues, including authentic Pakistani, Chinese, and Continental cuisines. The hotel's comprehensive amenities cater to every need of the discerning traveler.",
    amenities: ["wifi", "pool", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Standard Room", price: 26500 },
      { name: "Business Class", price: 38000 },
      { name: "Luxury Suite", price: 65000 }
    ],
    images: defaultImages,
    guestRating: 4.7,
    reviewCount: 980,
    reviews: sampleReviews
  },
  {
    id: "nishat-hotel-gulberg",
    name: "Nishat Hotel",
    area: "Gulberg",
    starRating: 5,
    pricePerNight: 32000,
    description: "The Nishat Hotel in Gulberg sets a new standard for boutique luxury in Lahore. With its chic, contemporary design and sophisticated ambiance, it appeals to modern travelers seeking style and substance. The elegantly appointed rooms feature premium furnishings and cutting-edge technology.\n\nLocated in the upscale Gulberg neighborhood, guests have immediate access to high-end shopping and entertainment. The hotel's own facilities, including a serene indoor pool and top-tier dining, provide a perfect retreat.",
    amenities: ["wifi", "pool", "spa", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Classic Room", price: 32000 },
      { name: "Premium Room", price: 42000 },
      { name: "Nishat Suite", price: 75000 }
    ],
    images: defaultImages,
    guestRating: 4.9,
    reviewCount: 850,
    reviews: sampleReviews
  },
  {
    id: "luxus-grand",
    name: "Luxus Grand Hotel",
    area: "Mall Road",
    starRating: 4,
    pricePerNight: 18000,
    description: "Luxus Grand Hotel offers a refined stay with a focus on personalized service and comfort. Its striking architecture and lavish interiors create an inviting atmosphere for guests. The spacious accommodations are designed with a keen eye for detail, ensuring a restful and luxurious experience.\n\nThe hotel boasts excellent dining options, state-of-the-art conference facilities, and a dedicated wellness center, making it an ideal choice for both corporate and leisure guests looking for premium quality at a great value.",
    amenities: ["wifi", "pool", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Executive Room", price: 18000 },
      { name: "Junior Suite", price: 25000 },
      { name: "Grand Suite", price: 45000 }
    ],
    images: defaultImages,
    guestRating: 4.6,
    reviewCount: 620,
    reviews: sampleReviews
  },
  {
    id: "hospitality-inn",
    name: "Hospitality Inn",
    area: "Egerton Road",
    starRating: 4,
    pricePerNight: 15500,
    description: "Conveniently located on Egerton Road, Hospitality Inn provides a perfect blend of comfort and convenience. The hotel is renowned for its warm, welcoming staff and well-maintained facilities. Guests can enjoy panoramic views of the city from the higher floors.\n\nWhether dining at the rooftop restaurant or relaxing in the health club, Hospitality Inn ensures a pleasant and memorable stay with easy access to major commercial and cultural hubs of Lahore.",
    amenities: ["wifi", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Standard Room", price: 15500 },
      { name: "Deluxe Room", price: 20000 },
      { name: "Executive Suite", price: 35000 }
    ],
    images: defaultImages,
    guestRating: 4.4,
    reviewCount: 450,
    reviews: sampleReviews
  },
  {
    id: "falettis-hotel",
    name: "Faletti's Hotel",
    area: "Egerton Road",
    starRating: 5,
    pricePerNight: 24000,
    description: "Steeped in history, Faletti's Hotel is a colonial-era gem that has been meticulously restored to offer timeless luxury. Walking through its corridors is like taking a step back in time, yet the accommodations feature all the modern amenities expected of a five-star property.\n\nThe sprawling courtyards, grand banquet halls, and classic culinary offerings make it a unique and prestigious choice for those who appreciate heritage and elegance.",
    amenities: ["wifi", "spa", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Heritage Room", price: 24000 },
      { name: "Historical Suite", price: 40000 },
      { name: "Ava Gardner Suite", price: 60000 }
    ],
    images: defaultImages,
    guestRating: 4.8,
    reviewCount: 1100,
    reviews: sampleReviews
  },
  {
    id: "ramada-lahore-gulberg",
    name: "Ramada Lahore Gulberg",
    area: "Gulberg",
    starRating: 4,
    pricePerNight: 22000,
    description: "Ramada Lahore Gulberg brings international hospitality standards to one of Lahore's most vibrant neighborhoods. The hotel features modern design, comfortable accommodations, and exceptional service. It's perfectly situated for guests looking to explore the city's finest dining and retail options.\n\nEnjoy a diverse range of international cuisines, relax in the well-appointed spa, and take advantage of the sophisticated business center during your stay.",
    amenities: ["wifi", "pool", "spa", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Deluxe Room", price: 22000 },
      { name: "Executive Room", price: 30000 },
      { name: "Suite", price: 50000 }
    ],
    images: defaultImages,
    guestRating: 4.5,
    reviewCount: 750,
    reviews: sampleReviews
  },
  {
    id: "royal-palm-lakefront",
    name: "Royal Palm Lakefront",
    area: "Canal Bank",
    starRating: 5,
    pricePerNight: 35000,
    description: "An exclusive resort-style hotel situated along the scenic Canal Bank. Royal Palm Lakefront offers unparalleled privacy and luxury, featuring extensive grounds, a pristine golf course, and stunning water views. It's an oasis of tranquility designed for the ultimate relaxation.\n\nThe accommodations are incredibly spacious, boasting custom furnishings and private balconies. With multiple high-end dining venues and an elite country club atmosphere, it's the pinnacle of luxury in Lahore.",
    amenities: ["wifi", "pool", "spa", "restaurant", "parking", "gym", "room-service", "bar"],
    roomTypes: [
      { name: "Lakeview Room", price: 35000 },
      { name: "Golf View Suite", price: 55000 },
      { name: "Royal Villa", price: 95000 }
    ],
    images: defaultImages,
    guestRating: 4.9,
    reviewCount: 420,
    reviews: sampleReviews
  },
  {
    id: "hotel-one-dha",
    name: "Hotel One",
    area: "DHA",
    starRating: 3,
    pricePerNight: 12000,
    description: "Hotel One provides a smart, efficient, and comfortable stay in the upscale DHA area. Known for its clean, contemporary rooms and reliable service, it caters perfectly to budget-conscious travelers who do not want to compromise on quality and location.\n\nThe hotel offers a cozy dining area, seamless connectivity, and easy access to DHA's popular commercial zones.",
    amenities: ["wifi", "restaurant", "parking", "room-service"],
    roomTypes: [
      { name: "Standard Room", price: 12000 },
      { name: "Deluxe Room", price: 16000 }
    ],
    images: defaultImages,
    guestRating: 4.2,
    reviewCount: 380,
    reviews: sampleReviews
  },
  {
    id: "park-lane-hotel",
    name: "Park Lane Hotel",
    area: "MM Alam Road",
    starRating: 4,
    pricePerNight: 20000,
    description: "Located right on the famous MM Alam Road, Park Lane Hotel places you in the heart of Lahore's culinary and shopping district. The hotel features an elegant facade and thoughtfully designed interiors that exude warmth and sophistication.\n\nGuests can enjoy the rooftop pool with panoramic city views, fine dining at the in-house restaurant, and luxurious rooms that serve as a perfect sanctuary after a busy day.",
    amenities: ["wifi", "pool", "restaurant", "parking", "gym", "room-service"],
    roomTypes: [
      { name: "Deluxe Room", price: 20000 },
      { name: "Executive Suite", price: 32000 }
    ],
    images: defaultImages,
    guestRating: 4.6,
    reviewCount: 510,
    reviews: sampleReviews
  }
];