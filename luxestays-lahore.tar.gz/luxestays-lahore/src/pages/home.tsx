import { Layout } from "@/components/layout";
import { hotels } from "@/data/hotels";
import { HotelCard } from "@/components/ui/hotel-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Search, MapPin, Star } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();
  const [searchName, setSearchName] = useState("");
  const [area, setArea] = useState("");
  const [maxPrice, setMaxPrice] = useState([35000]);

  const featuredHotels = hotels.slice(0, 3);
  const areas = ["Gulberg", "DHA", "Mall Road", "Bahria Town", "Johar Town", "Egerton Road"];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchName) params.set("q", searchName);
    if (area) params.set("area", area);
    params.set("price", maxPrice[0].toString());
    setLocation(`/hotels?${params.toString()}`);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[90dvh] flex items-center pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hotel-exterior-1.png" 
            alt="Lahore Skyline" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-primary/80 via-primary/60 to-background"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center max-w-4xl">
          <span className="inline-block py-1 px-3 rounded-full bg-secondary/20 text-secondary font-medium tracking-widest text-xs uppercase mb-6 backdrop-blur-md border border-secondary/30 animate-in fade-in slide-in-from-bottom-4 duration-700">
            Welcome to LuxeStays
          </span>
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-white mb-6 leading-tight animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-150">
            Discover Lahore's Most <span className="text-secondary italic">Exquisite</span> Stays
          </h1>
          <p className="text-lg md:text-xl text-white/80 mb-12 max-w-2xl mx-auto font-light leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-300">
            Immerse yourself in opulence. Handpicked luxury hotels offering world-class hospitality in the cultural heart of Pakistan.
          </p>

          <form onSubmit={handleSearch} className="bg-white p-4 rounded-3xl shadow-2xl flex flex-col md:flex-row gap-4 items-end md:items-center max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-500">
            <div className="w-full md:w-1/3 text-left">
              <Label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1 mb-1 block">Hotel Name</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="e.g. Pearl Continental" 
                  className="pl-9 bg-muted/50 border-none h-12 rounded-xl"
                  value={searchName}
                  onChange={(e) => setSearchName(e.target.value)}
                />
              </div>
            </div>
            
            <div className="w-full md:w-1/4 text-left">
              <Label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1 mb-1 block">Area</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <select 
                  className="w-full pl-9 pr-4 bg-muted/50 border-none h-12 rounded-xl text-sm outline-none appearance-none"
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                >
                  <option value="">Any Area</option>
                  {areas.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
            </div>

            <div className="w-full md:w-1/4 text-left px-2">
              <Label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 flex justify-between">
                <span>Max Price</span>
                <span className="text-primary font-bold">PKR {maxPrice[0].toLocaleString()}</span>
              </Label>
              <Slider 
                value={maxPrice} 
                onValueChange={setMaxPrice} 
                max={100000} 
                step={1000}
                className="my-4"
              />
            </div>

            <Button type="submit" className="w-full md:w-auto h-12 px-8 rounded-xl font-bold bg-primary text-white hover:bg-secondary hover:text-primary transition-all">
              Find Stay
            </Button>
          </form>
        </div>
      </section>

      {/* Featured Section */}
      <section className="py-24 bg-background relative">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div className="max-w-2xl">
              <h2 className="font-serif text-4xl font-bold mb-4">Featured Properties</h2>
              <p className="text-muted-foreground text-lg">Experience the pinnacle of luxury with our most highly-rated and sought-after destinations.</p>
            </div>
            <Button variant="outline" className="rounded-full px-6 h-12 font-medium border-border hover:border-secondary hover:bg-secondary/5" onClick={() => setLocation("/hotels")}>
              View All Hotels
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredHotels.map(hotel => (
              <HotelCard key={hotel.id} hotel={hotel} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-primary text-white overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('/images/hotel-lobby-1.png')] opacity-10 bg-cover bg-center bg-fixed"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="font-serif text-4xl font-bold mb-4 text-white">Why Book With LuxeStays</h2>
            <p className="text-white/70 text-lg">We curate only the finest establishments to guarantee an unforgettable experience in Lahore.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div>
              <div className="w-16 h-16 mx-auto bg-secondary/20 rounded-full flex items-center justify-center mb-6">
                <Star className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-3">Handpicked Selection</h3>
              <p className="text-white/60 leading-relaxed">Every hotel is personally vetted by our team to ensure it meets our strict luxury standards.</p>
            </div>
            <div>
              <div className="w-16 h-16 mx-auto bg-secondary/20 rounded-full flex items-center justify-center mb-6">
                <MapPin className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-3">Prime Locations</h3>
              <p className="text-white/60 leading-relaxed">From the bustling Mall Road to the serene Canal Bank, stay where you want to be.</p>
            </div>
            <div>
              <div className="w-16 h-16 mx-auto bg-secondary/20 rounded-full flex items-center justify-center mb-6">
                <Search className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-3">Seamless Discovery</h3>
              <p className="text-white/60 leading-relaxed">Effortlessly find, compare, and connect with properties that match your exact desires.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-accent text-center">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="font-serif text-4xl md:text-5xl font-bold mb-6 text-foreground">Ready for an Unforgettable Stay?</h2>
          <p className="text-xl text-muted-foreground mb-10 font-light">
            Browse our full collection of luxury properties and find your perfect escape in Lahore.
          </p>
          <Button size="lg" className="h-14 px-10 text-lg rounded-full shadow-xl shadow-primary/20 bg-primary text-white hover:bg-secondary hover:text-primary transition-colors" onClick={() => setLocation("/hotels")}>
            Explore All Hotels
          </Button>
        </div>
      </section>
    </Layout>
  );
}