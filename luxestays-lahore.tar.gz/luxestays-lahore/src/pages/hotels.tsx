import { Layout } from "@/components/layout";
import { hotels, Amenity } from "@/data/hotels";
import { HotelCard } from "@/components/ui/hotel-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Filter, Search } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

const AMENITIES: { id: Amenity; label: string }[] = [
  { id: "wifi", label: "Free WiFi" },
  { id: "pool", label: "Swimming Pool" },
  { id: "spa", label: "Spa & Wellness" },
  { id: "restaurant", label: "Restaurant" },
  { id: "parking", label: "Valet Parking" },
  { id: "gym", label: "Fitness Center" },
];

export default function Hotels() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "");
  const [selectedArea, setSelectedArea] = useState(searchParams.get("area") || "");
  const [maxPrice, setMaxPrice] = useState([parseInt(searchParams.get("price") || "100000")]);
  const [selectedStars, setSelectedStars] = useState<number[]>([]);
  const [selectedAmenities, setSelectedAmenities] = useState<Amenity[]>([]);

  const areas = Array.from(new Set(hotels.map(h => h.area))).sort();

  const filteredHotels = hotels.filter(hotel => {
    if (searchQuery && !hotel.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (selectedArea && hotel.area !== selectedArea) return false;
    if (hotel.pricePerNight > maxPrice[0]) return false;
    if (selectedStars.length > 0 && !selectedStars.includes(hotel.starRating)) return false;
    if (selectedAmenities.length > 0 && !selectedAmenities.every(a => hotel.amenities.includes(a))) return false;
    return true;
  });

  const toggleStar = (star: number) => {
    setSelectedStars(prev => prev.includes(star) ? prev.filter(s => s !== star) : [...prev, star]);
  };

  const toggleAmenity = (amenity: Amenity) => {
    setSelectedAmenities(prev => prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]);
  };

  const FilterContent = () => (
    <div className="space-y-8">
      <div>
        <Label className="text-sm font-bold uppercase tracking-wider mb-3 block text-muted-foreground">Search</Label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Hotel name..." 
            className="pl-9 h-12 bg-muted/50 border-none rounded-xl"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div>
        <Label className="text-sm font-bold uppercase tracking-wider mb-3 block text-muted-foreground">Area</Label>
        <select 
          className="w-full px-4 h-12 bg-muted/50 border-none rounded-xl text-sm outline-none"
          value={selectedArea}
          onChange={e => setSelectedArea(e.target.value)}
        >
          <option value="">All Areas</option>
          {areas.map(a => <option key={a} value={a}>{a}</option>)}
        </select>
      </div>

      <div>
        <Label className="text-sm font-bold uppercase tracking-wider mb-3 flex justify-between text-muted-foreground">
          <span>Max Price</span>
          <span className="text-primary font-bold">PKR {maxPrice[0].toLocaleString()}</span>
        </Label>
        <Slider 
          value={maxPrice} 
          onValueChange={setMaxPrice} 
          max={100000} 
          step={1000}
          className="my-4"
        />
      </div>

      <div>
        <Label className="text-sm font-bold uppercase tracking-wider mb-3 block text-muted-foreground">Star Rating</Label>
        <div className="space-y-3">
          {[5, 4, 3].map(star => (
            <div key={star} className="flex items-center space-x-3">
              <Checkbox 
                id={`star-${star}`} 
                checked={selectedStars.includes(star)}
                onCheckedChange={() => toggleStar(star)}
              />
              <label htmlFor={`star-${star}`} className="text-sm font-medium leading-none cursor-pointer flex items-center gap-1">
                {star} Stars
              </label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label className="text-sm font-bold uppercase tracking-wider mb-3 block text-muted-foreground">Amenities</Label>
        <div className="space-y-3">
          {AMENITIES.map(amenity => (
            <div key={amenity.id} className="flex items-center space-x-3">
              <Checkbox 
                id={`amenity-${amenity.id}`} 
                checked={selectedAmenities.includes(amenity.id)}
                onCheckedChange={() => toggleAmenity(amenity.id)}
              />
              <label htmlFor={`amenity-${amenity.id}`} className="text-sm font-medium leading-none cursor-pointer">
                {amenity.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      <Button 
        variant="outline" 
        className="w-full h-12 rounded-xl border-border"
        onClick={() => {
          setSearchQuery("");
          setSelectedArea("");
          setMaxPrice([100000]);
          setSelectedStars([]);
          setSelectedAmenities([]);
        }}
      >
        Reset Filters
      </Button>
    </div>
  );

  return (
    <Layout>
      <div className="bg-primary pt-12 pb-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/hotel-lobby-1.png')] opacity-10 bg-cover bg-center"></div>
        <div className="container mx-auto px-4 relative z-10">
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">Our Collection</h1>
          <p className="text-white/70 text-lg max-w-2xl">Discover Lahore's most prestigious accommodations. Filter by your exact preferences to find the perfect stay.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-10 relative z-20 pb-24">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Mobile Filter Button */}
          <div className="lg:hidden w-full flex justify-end">
            <Sheet>
              <SheetTrigger asChild>
                <Button className="h-12 px-6 rounded-full bg-white text-primary hover:bg-secondary hover:text-primary shadow-xl">
                  <Filter className="w-4 h-4 mr-2" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-y-auto">
                <div className="py-6">
                  <h2 className="font-serif text-2xl font-bold mb-8">Filters</h2>
                  <FilterContent />
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Desktop Sidebar */}
          <div className="hidden lg:block w-1/4 shrink-0">
            <div className="bg-card border border-border p-6 rounded-3xl shadow-sm sticky top-28">
              <FilterContent />
            </div>
          </div>

          {/* Grid */}
          <div className="w-full lg:w-3/4">
            <div className="mb-6 flex justify-between items-center bg-card border border-border p-4 rounded-2xl shadow-sm">
              <span className="text-sm font-medium text-muted-foreground">
                Showing <strong className="text-foreground">{filteredHotels.length}</strong> luxurious stays
              </span>
            </div>

            {filteredHotels.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredHotels.map(hotel => (
                  <HotelCard key={hotel.id} hotel={hotel} />
                ))}
              </div>
            ) : (
              <div className="bg-card border border-border rounded-3xl p-12 text-center">
                <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="font-serif text-2xl font-bold mb-2">No hotels found</h3>
                <p className="text-muted-foreground mb-6">We couldn't find any properties matching your exact filters.</p>
                <Button 
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedArea("");
                    setMaxPrice([100000]);
                    setSelectedStars([]);
                    setSelectedAmenities([]);
                  }}
                  className="rounded-full"
                >
                  Clear all filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}