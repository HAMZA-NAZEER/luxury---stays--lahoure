import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent",
      description: "Thank you for reaching out. Hamza Nazeer will get back to you shortly.",
    });
    (e.target as HTMLFormElement).reset();
  };

  return (
    <Layout>
      <div className="bg-primary text-white pt-24 pb-32">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6">Let's Connect</h1>
          <p className="text-xl text-white/70">
            Whether you need help finding the perfect stay or want to list your property on LuxeStays, we're here to help.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-16 relative z-10 pb-24">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Contact Form */}
          <div className="lg:w-2/3 bg-card border border-border p-8 md:p-12 rounded-3xl shadow-xl">
            <h2 className="font-serif text-3xl font-bold mb-8">Send a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input required className="h-12 bg-muted/50" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <Input required type="tel" className="h-12 bg-muted/50" placeholder="+92 3XX XXXXXXX" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Email Address</Label>
                <Input required type="email" className="h-12 bg-muted/50" placeholder="john@example.com" />
              </div>
              <div className="space-y-2">
                <Label>Message</Label>
                <Textarea required className="min-h-[150px] bg-muted/50" placeholder="How can we help you?" />
              </div>
              <Button type="submit" size="lg" className="w-full md:w-auto px-10 h-12 rounded-full font-bold">
                Send Message
              </Button>
            </form>
          </div>

          {/* Contact Details */}
          <div className="lg:w-1/3 space-y-8">
            <div className="bg-card border border-border p-8 rounded-3xl shadow-sm">
              <h3 className="font-serif text-2xl font-bold mb-6">Direct Contact</h3>
              
              <div className="space-y-6">
                <div>
                  <div className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Founder</div>
                  <div className="font-serif text-xl text-primary font-bold">Hamza Nazeer</div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5 text-secondary" />
                  </div>
                  <div>
                    <div className="font-medium mb-1">Phone & WhatsApp</div>
                    <a href="tel:03186732515" className="text-muted-foreground hover:text-primary block mb-1">0318 6732515</a>
                    <a href="https://wa.me/923186732515" target="_blank" rel="noreferrer" className="text-secondary font-medium hover:underline text-sm">Message on WhatsApp</a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5 text-secondary" />
                  </div>
                  <div>
                    <div className="font-medium mb-1">Email</div>
                    <a href="mailto:hamzanazeer@email.com" className="text-muted-foreground hover:text-primary">hamzanazeer@email.com</a>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border p-8 rounded-3xl shadow-sm">
              <h3 className="font-serif text-2xl font-bold mb-6">Information</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="font-medium mb-1">Headquarters</div>
                    <div className="text-muted-foreground">Gulberg III, Lahore<br/>Pakistan</div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="font-medium mb-1">Business Hours</div>
                    <div className="text-muted-foreground">Monday - Saturday<br/>9:00 AM - 8:00 PM</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Map Placeholder */}
        <div className="mt-16 bg-muted rounded-3xl h-[400px] flex items-center justify-center border border-border relative overflow-hidden">
          <div className="absolute inset-0 opacity-20 bg-[url('https://api.maptiler.com/maps/basic-v2/static/74.3587,31.5204,12/1000x400.png?key=placeholder')] bg-cover bg-center"></div>
          <div className="text-center relative z-10 bg-background/80 backdrop-blur-md p-6 rounded-2xl border border-border shadow-xl">
            <MapPin className="w-10 h-10 text-primary mx-auto mb-2" />
            <h3 className="font-serif text-xl font-bold">LuxeStays Lahore</h3>
            <p className="text-muted-foreground">Serving the finest properties across the city</p>
          </div>
        </div>
      </div>
    </Layout>
  );
}