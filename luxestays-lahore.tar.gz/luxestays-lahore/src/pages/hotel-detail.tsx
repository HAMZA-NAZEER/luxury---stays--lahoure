import { Layout } from "@/components/layout";
import { hotels, Amenity } from "@/data/hotels";
import { useRoute } from "wouter";
import { Star, MapPin, Heart, Wifi, Waves, Wind, Utensils, Car, Dumbbell, Coffee, Martini, Check, Phone, Mail } from "lucide-react";
import { useFavorites } from "@/hooks/use-favorites";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

const amenityIcons: Record<Amenity, React.ReactNode> = {
  wifi: <Wifi className="w-5 h-5" />,
  pool: <Waves className="w-5 h-5" />,
  spa: <Wind className="w-5 h-5" />,
  restaurant: <Utensils className="w-5 h-5" />,
  parking: <Car className="w-5 h-5" />,
  gym: <Dumbbell className="w-5 h-5" />,
  "room-service": <Coffee className="w-5 h-5" />,
  bar: <Martini className="w-5 h-5" />
};

const amenityLabels: Record<Amenity, string> = {
  wifi: "Free High-Speed WiFi",
  pool: "Infinity Pool",
  spa: "Luxury Spa",
  restaurant: "Fine Dining",
  parking: "Valet Parking",
  gym: "Fitness Center",
  "room-service": "24/7 Room Service",
  bar: "Lounge Bar"
};

export default function HotelDetail() {
  const [, params] = useRoute("/hotels/:id");
  const hotel = hotels.find(h => h.id === params?.id);
  const { isFavorite, toggleFavorite } = useFavorites();
  const { toast } = useToast();
  const [isContactOpen, setIsContactOpen] = useState(false);

  if (!hotel) {
    return (
      <Layout>
        <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
          <h1 className="font-serif text-4xl font-bold mb-4">Hotel Not Found</h1>
          <p className="text-muted-foreground mb-8">The property you are looking for does not exist or has been removed.</p>
          <Button onClick={() => window.history.back()} className="rounded-full">Go Back</Button>
        </div>
      </Layout>
    );
  }

  const isFav = isFavorite(hotel.id);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsContactOpen(false);
    toast({
      title: "Request Sent Successfully",
      description: `Hamza Nazeer will contact you shortly regarding your booking at ${hotel.name}.`,
    });
  };

  return (
    <Layout>
      {/* Gallery Header */}
      <div className="w-full bg-background pt-6 pb-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-[50vh] md:h-[60vh] rounded-3xl overflow-hidden">
            <div className="md:col-span-2 md:row-span-2 h-full">
              <img src={hotel.images[0]} alt={hotel.name} className="w-full h-full object-cover" />
            </div>
            <div className="hidden md:block h-full">
              <img src={hotel.images[1]} alt={hotel.name} className="w-full h-full object-cover" />
            </div>
            <div className="hidden md:block h-full">
              <img src={hotel.images[2]} alt={hotel.name} className="w-full h-full object-cover" />
            </div>
            <div className="hidden md:block h-full">
              <img src={hotel.images[3]} alt={hotel.name} className="w-full h-full object-cover" />
            </div>
            <div className="hidden md:block h-full relative">
              <img src={hotel.images[4] || hotel.images[0]} alt={hotel.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <Button variant="outline" className="bg-white/10 backdrop-blur-md text-white border-white/30 hover:bg-white hover:text-black rounded-full">
                  View All Photos
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 pb-24">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Content */}
          <div className="lg:w-2/3">
            <div className="flex flex-wrap justify-between items-start gap-6 mb-6">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="secondary" className="bg-secondary/20 text-secondary border-none hover:bg-secondary/30">
                    Luxury Hotel
                  </Badge>
                  <div className="flex">
                    {Array.from({ length: hotel.starRating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-secondary text-secondary" />
                    ))}
                  </div>
                </div>
                <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-4">{hotel.name}</h1>
                <div className="flex items-center gap-2 text-muted-foreground text-lg">
                  <MapPin className="w-5 h-5" />
                  <span>{hotel.area}, Lahore, Pakistan</span>
                </div>
              </div>
              <button 
                onClick={() => toggleFavorite(hotel.id)}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all border ${isFav ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-card text-muted-foreground border-border hover:bg-muted'}`}
              >
                <Heart className={`w-6 h-6 ${isFav ? 'fill-current' : ''}`} />
              </button>
            </div>

            <div className="prose prose-lg dark:prose-invert max-w-none mb-12">
              {hotel.description.split('\n\n').map((p, i) => (
                <p key={i} className="text-muted-foreground leading-relaxed">{p}</p>
              ))}
            </div>

            <div className="mb-12">
              <h2 className="font-serif text-2xl font-bold mb-6">Premium Amenities</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {hotel.amenities.map(amenity => (
                  <div key={amenity} className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary">
                      {amenityIcons[amenity]}
                    </div>
                    <span className="font-medium">{amenityLabels[amenity]}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-12">
              <h2 className="font-serif text-2xl font-bold mb-6">Available Room Types</h2>
              <div className="space-y-4">
                {hotel.roomTypes.map((room, i) => (
                  <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between p-6 rounded-2xl border border-border bg-card hover:border-secondary/50 transition-colors">
                    <div>
                      <h3 className="text-xl font-bold mb-2">{room.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1"><Check className="w-4 h-4 text-secondary" /> King Bed</span>
                        <span className="flex items-center gap-1"><Check className="w-4 h-4 text-secondary" /> City View</span>
                      </div>
                    </div>
                    <div className="mt-4 sm:mt-0 text-left sm:text-right">
                      <div className="text-2xl font-bold text-primary">PKR {room.price.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">per night</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-4 mb-8">
                <h2 className="font-serif text-2xl font-bold">Guest Reviews</h2>
                <div className="flex items-center gap-2 bg-secondary text-primary px-3 py-1 rounded-lg font-bold">
                  <Star className="w-4 h-4 fill-current" />
                  {hotel.guestRating} <span className="text-sm font-normal opacity-80">({hotel.reviewCount})</span>
                </div>
              </div>
              <div className="space-y-6">
                {hotel.reviews.map(review => (
                  <div key={review.id} className="bg-muted/30 p-6 rounded-2xl">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="font-bold text-lg">{review.author}</div>
                        <div className="text-sm text-muted-foreground">{review.date}</div>
                      </div>
                      <div className="flex items-center bg-background px-2 py-1 rounded-md border border-border text-sm font-bold">
                        <Star className="w-3.5 h-3.5 fill-secondary text-secondary mr-1" />
                        {review.rating}
                      </div>
                    </div>
                    <p className="text-muted-foreground italic">"{review.text}"</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sticky Sidebar */}
          <div className="lg:w-1/3">
            <div className="bg-primary text-primary-foreground rounded-3xl p-8 sticky top-28 shadow-2xl">
              <div className="text-secondary font-medium tracking-widest text-xs uppercase mb-2">Starting from</div>
              <div className="text-4xl font-serif font-bold mb-1">PKR {hotel.pricePerNight.toLocaleString()}</div>
              <div className="text-primary-foreground/60 text-sm mb-8">per night, taxes included</div>

              <div className="space-y-6 mb-8">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                    <Star className="w-5 h-5 text-secondary fill-secondary" />
                  </div>
                  <div>
                    <div className="font-bold">{hotel.guestRating} Exceptional</div>
                    <div className="text-sm text-primary-foreground/60">{hotel.reviewCount} reviews</div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-secondary" />
                  </div>
                  <div>
                    <div className="font-bold">Prime Location</div>
                    <div className="text-sm text-primary-foreground/60">{hotel.area}</div>
                  </div>
                </div>
              </div>

              <Dialog open={isContactOpen} onOpenChange={setIsContactOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full h-14 text-lg rounded-xl font-bold bg-secondary text-primary hover:bg-white transition-colors">
                    Contact for Booking
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="font-serif text-2xl">Book {hotel.name}</DialogTitle>
                    <DialogDescription>
                      Send a request to Hamza Nazeer to secure your dates and get the best available rates.
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleContactSubmit} className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input required placeholder="John Doe" />
                    </div>
                    <div className="space-y-2">
                      <Label>Phone Number</Label>
                      <Input required type="tel" placeholder="+92 3XX XXXXXXX" />
                    </div>
                    <div className="space-y-2">
                      <Label>Dates & Requests</Label>
                      <Textarea required placeholder="I would like to book a Deluxe Room from..." className="min-h-[100px]" />
                    </div>
                    <Button type="submit" className="w-full h-12 font-bold mt-2">Send Request</Button>
                  </form>
                  <div className="mt-4 pt-4 border-t border-border flex flex-col gap-2">
                    <div className="text-sm text-center text-muted-foreground mb-2">Or contact directly:</div>
                    <a href="tel:03186732515" className="flex items-center justify-center gap-2 w-full h-10 rounded-md border border-border hover:bg-muted text-sm font-medium">
                      <Phone className="w-4 h-4" /> 0318 6732515
                    </a>
                    <a href="https://wa.me/923186732515" target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 w-full h-10 rounded-md bg-[#25D366] text-white hover:bg-[#20bd5a] text-sm font-medium">
                      <span className="font-bold text-lg leading-none">W</span> WhatsApp Message
                    </a>
                  </div>
                </DialogContent>
              </Dialog>

              <p className="text-center text-xs text-primary-foreground/50 mt-4">
                No credit card needed to request.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}