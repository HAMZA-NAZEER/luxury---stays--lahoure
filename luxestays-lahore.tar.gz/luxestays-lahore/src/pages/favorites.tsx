import { Layout } from "@/components/layout";
import { hotels } from "@/data/hotels";
import { HotelCard } from "@/components/ui/hotel-card";
import { useFavorites } from "@/hooks/use-favorites";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";
import { Link } from "wouter";

export default function Favorites() {
  const { favorites } = useFavorites();
  
  const favoriteHotels = hotels.filter(h => favorites.includes(h.id));

  return (
    <Layout>
      <div className="container mx-auto px-4 py-16 min-h-[70vh]">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center">
            <Heart className="w-6 h-6 text-secondary fill-secondary" />
          </div>
          <h1 className="font-serif text-4xl font-bold">Your Wishlist</h1>
        </div>

        {favoriteHotels.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {favoriteHotels.map(hotel => (
              <HotelCard key={hotel.id} hotel={hotel} />
            ))}
          </div>
        ) : (
          <div className="bg-card border border-border rounded-3xl p-16 text-center max-w-2xl mx-auto mt-12 shadow-sm">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-10 h-10 text-muted-foreground" />
            </div>
            <h2 className="font-serif text-3xl font-bold mb-4">No favorites yet</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Explore our collection of luxury properties and save your favorites here for easy access later.
            </p>
            <Link href="/hotels">
              <Button size="lg" className="rounded-full px-8 h-14 text-lg">
                Browse Hotels
              </Button>
            </Link>
          </div>
        )}
      </div>
    </Layout>
  );
}