import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function About() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-secondary/10 rounded-bl-[200px] -z-10"></div>
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <span className="inline-block py-1 px-3 rounded-full bg-secondary/20 text-secondary font-medium tracking-widest text-xs uppercase mb-6">Our Story</span>
            <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6 leading-tight">Redefining Luxury Hospitality in Lahore</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              LuxeStays was born out of a simple passion: to showcase the unparalleled beauty, culture, and hospitality of Lahore through its most magnificent properties.
            </p>
          </div>
        </div>
      </section>

      {/* Vision */}
      <section className="py-24 bg-card border-y border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="md:w-1/2">
              <img src="/images/hotel-lobby-1.png" alt="Luxury Lobby" className="rounded-3xl shadow-2xl" />
            </div>
            <div className="md:w-1/2">
              <h2 className="font-serif text-4xl font-bold mb-6">The Vision</h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Finding true luxury shouldn't be complicated. We realized that while Lahore possesses world-class hotels, there wasn't a dedicated platform that curated these premium experiences with the elegance they deserve.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We bridge the gap between discerning travelers and elite hoteliers. Every property on our platform is carefully evaluated to ensure it meets international standards of opulence, comfort, and service.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Band */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl font-serif font-bold text-secondary mb-2">50+</div>
              <div className="text-white/70 font-medium tracking-wider uppercase text-sm">Luxury Hotels</div>
            </div>
            <div>
              <div className="text-5xl font-serif font-bold text-secondary mb-2">10k+</div>
              <div className="text-white/70 font-medium tracking-wider uppercase text-sm">Happy Guests</div>
            </div>
            <div>
              <div className="text-5xl font-serif font-bold text-secondary mb-2">12</div>
              <div className="text-white/70 font-medium tracking-wider uppercase text-sm">Areas Covered</div>
            </div>
            <div>
              <div className="text-5xl font-serif font-bold text-secondary mb-2">24/7</div>
              <div className="text-white/70 font-medium tracking-wider uppercase text-sm">Dedicated Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Founder */}
      <section className="py-24">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <div className="w-32 h-32 mx-auto bg-primary rounded-full mb-8 flex items-center justify-center text-secondary font-serif text-5xl font-bold shadow-xl">
            HN
          </div>
          <h2 className="font-serif text-4xl font-bold mb-4">Meet the Founder</h2>
          <h3 className="text-xl text-primary font-medium mb-8">Hamza Nazeer</h3>
          <p className="text-lg text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto">
            "I created LuxeStays to bring the hidden gems of Lahore to the forefront. I believe that a hotel stay isn't just about a room—it's about the experience, the memories, and the impeccable service that makes you feel truly valued."
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/contact">
              <Button size="lg" className="rounded-full px-8">Get in Touch</Button>
            </Link>
            <Link href="/hotels">
              <Button size="lg" variant="outline" className="rounded-full px-8">View Collection</Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}