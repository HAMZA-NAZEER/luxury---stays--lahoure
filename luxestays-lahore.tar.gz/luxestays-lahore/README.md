# LuxeStays Lahore

A luxury hotel discovery website for Lahore, Pakistan. Browse premium hotels, filter by neighborhood, price, amenities and star rating, save favorites, and contact for bookings.

Built with React, TypeScript, Vite, Tailwind CSS, shadcn/ui, wouter, and Framer Motion.

## Features

- Multi-page experience (Home, Hotels, Hotel Detail, About, Contact, Favorites)
- Hotel search with filters (area, max price, star rating, amenities)
- Saved favorites stored in browser
- Account sign up / sign in (client-side, stored in browser)
- Fully responsive — mobile, tablet, desktop
- Contact and booking inquiry forms

## Getting Started

### Prerequisites

- Node.js 20+ (or 22+)
- npm, pnpm, or yarn

### Install dependencies

```bash
npm install
```

### Run the dev server

```bash
npm run dev
```

The site will be available at http://localhost:5173.

### Build for production

```bash
npm run build
```

The production-ready files are written to `dist/`.

### Preview the production build

```bash
npm run preview
```

## Project Structure

```
.
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── public/
└── src/
    ├── main.tsx          # App entrypoint
    ├── App.tsx           # Routes and global providers
    ├── index.css         # Theme tokens and global styles
    ├── components/       # Layout, header, footer, auth dialog, UI primitives
    ├── pages/            # Home, Hotels, Hotel Detail, About, Contact, Favorites
    ├── data/             # Hotel catalog
    ├── hooks/            # use-auth, use-favorites, use-toast
    └── lib/              # Utilities
```

## Deployment

The build output in `dist/` is a static site and can be hosted on any static host (Vercel, Netlify, GitHub Pages, Cloudflare Pages, S3 + CloudFront, etc.).

## Contact

- **Hamza Nazeer**
- Phone: 0318 6732515
- WhatsApp: https://wa.me/923186732515
- Email: hamzanazeer@email.com

## License

MIT — see [LICENSE](./LICENSE).
